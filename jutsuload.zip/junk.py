if __name__ == "__main__":
    singlepage = True
    if singlepage:
        # 'https://jut.su/yakusoku-neverland/season-2/episode-7.html'
        page = Episode(input("URL of episode page: "))
        choice = int(
            input("\n".join([f"{i + 1}) {list(page.urls.keys())[i]}" for i in range(len(page.urls))]) + "\n? "))
        if 0 < choice <= len(page.urls):
            url = page.urls[list(page.urls.keys())[choice - 1]]
        else:
            raise IndexError("Think again.")
        print(url)
        if input("Download? (y/n) [y] ").lower().strip() in ['y', '']:
            filename = 'test.mp4'
            if os.path.exists(filename):
                if input("File exists. Overwrite? (y/n) [n]").lower().strip() == 'y':
                    download(url, filename, progress=True)
    else:
        eps = get_eps('https://jut.su/yakusoku-neverland')
        _ = filter(''.__ne__, input('\n'.join(['{}) S{} EP{}'.format(i + 1, *get_info(eps[i])[1:]) for i in range(
            len(eps))]) + '\nWhat do you want downloaded? (for example 1-15, 1-15 20-25 17, 2)'))
        dlist = set()
        try:
            for i in slicer(*_):
                dlist.update(i)
        except ValueError:
            print('Wrong number! Try again: ')